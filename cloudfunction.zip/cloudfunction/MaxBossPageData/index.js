// 云函数入口文件
const cloud = require('wx-server-sdk');
const jquery = require("./node_modules/jquery/dist/jquery.js");
const cheerio = require("cheerio");

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
   try{
    var html = JSON.stringify(event.html); // 转化为json格式
    let $ = cheerio.load(html);
    // let trs = html.$('.J-contain_detail_cnt');
    return await {
      event,
      list : {
        aa : $,
        bb : 11
      },
      a : 2,
      b : 3
    }
   } catch(res) {
     console.error(res)
   }
}