// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database({
  env : "wei-0804"
})

const _ = db.command;


// 云函数入口函数
exports.main = async (event, context) => {
   try{
    const MaxBossDB = db.collection("MaxBoss")

    //  请求热闻置顶项目 
    if( event.type == "queryTopNewsList" ){

      return await MaxBossDB.doc("topNewsList").get();

      // 判断用户是否存在
    } else if( event.type == "queryDbUser" ){

      return await  MaxBossDB.doc(event.cloudId).get();

      // 判断是否添加用户
    } else if(event.type == "addDbUser") {
      return await MaxBossDB.add({
       data : {
        _id : event.cloudId,
        userImg : event.avatarUrl,
        userName : event.nickName,
        userCity : event.city,
        time : db.serverDate,
        userCountry : event.country,
       }
      })
      // 更新数据
    } else if(event.type == "upData"){
      return await MaxBossDB.doc(event.cloudId).update({
        data : {
          data : _.push(event.src)
        }
      })
    }  else if(event.type == "upVideoData"){
      return await MaxBossDB.doc(event.cloudId).update({
        data : {
          videoData : _.push(event.src)
        }
      })
    } else if(event.type == "whereData"){
      return await MaxBossDB.doc(event.cloudId).get({
        success(res){
          return res;
        }
      });
      // 删除数据表中的信息 数组对象中 -- 图片
    } else if(event.type == 'removeImg'){
      return await MaxBossDB.doc(event.cloudId).update({
        data : {
          data : _.pull({
            "id" : event.dataId,
            "url" : event.dataUrl
          })
        }
      })
        // 删除数据表中的信息 数组对象中 -- 视频
    } else if(event.type == 'removeVideo'){
      return await MaxBossDB.doc(event.cloudId).update({
        data : {
          videoData : _.pull({
            "id" : event.dataId,
            "url" : event.dataUrl
          })
        }
      })
      // 删除笔记
    } else if(event.type == "removeNote"){
      return await MaxBossDB.doc(event.cloudId).update({
        data : {
          note : _.pull({
            "id" : _.eq(event.dataId)
          })
        }
      })
      // 更新note
    } else if(event.type == "upDataNote"){
      return await MaxBossDB.doc(event.cloudId).update({
        data : {
          note : _.unshift(event.src)
        }
      })
    } 




    
   }catch(e){
     console.error(e);
   }
}